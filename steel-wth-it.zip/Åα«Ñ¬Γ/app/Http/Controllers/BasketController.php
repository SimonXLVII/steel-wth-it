<?php

namespace App\Http\Controllers;

use App\Models\Basket;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BasketController extends Controller
{
    public function index()
    {
        if (!Auth::user()) {
            return redirect()->route('index');
        }

        $baskets = Basket::where('user_id', auth()->user()->id)->get();

        return view('basket.index', ['baskets' => $baskets]);
    }

    public function basketAdd($id)
    {
        $product = Product::where('id', $id)->first();

        if ($product->count > 0) {
            Basket::create([
                'count' => 1,
                'sum' => $product->price,
                'user_id' => auth()->user()->id,
                'product_id' => $product->id
            ]);
        }

        return back();
    }
}
