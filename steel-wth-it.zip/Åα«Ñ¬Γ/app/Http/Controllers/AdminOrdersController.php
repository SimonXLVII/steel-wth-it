<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminOrdersController extends Controller
{
    public function orders()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }

        $orders = Order::all();
        $statuses = Status::all();

        return view('admin.orders', ['orders' => $orders, 'statuses' => $statuses]);
    }

    public function order()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }

        return view('admin.order');
    }
}
