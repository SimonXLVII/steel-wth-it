<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function login()
    {
        if (Auth::user())
        {
            return redirect()->route('index');
        }

        return view('auth.login');
    }

    public function loginCheck(Request $request)
    {
        if (Auth::attempt($request->only(['email', 'password']))) {
            $request->session()->regenerate();

            if (auth()->user()->role_id == 2) {
                return view('admin.index');
            }

            return redirect()->route('index');
        }

        return back()->withErrors([
            'errorLogin' => 'Ошибка входа!'
        ]);
    }

    public function logout()
    {
        Auth::logout();

        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect()->route('index');
    }
}
