<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function index()
    {
        if (!Auth::user() || auth()->user()->role_id != 1) {
            return redirect()->route('index');
        }

        return view('profile.index');
    }

    public function order()
    {
        if (!Auth::user() || auth()->user()->role_id != 1) {
            return redirect()->route('index');
        }

        return view('profile.order');
    }
}
