<?php

namespace App\Http\Controllers;

use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminPropertyController extends Controller
{
    
    public function properties()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }
        
        $properties = Property::all();

        return view('admin.properties', ['properties' => $properties]);
    }

    public function propertyInsert(Request $request)
    {
        $property = Property::create([
            'name' => $request->input('name'),
            'element' => $request->input('element')
        ]);

        if ($property) {

            return redirect()->route('properties');
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function propertyUpdate(Request $request, $id)
    {
        $property = Property::where('id', $id)->first();

        $property = $property->update([
            'name' => $request->input('name'),
            'element' => $request->input('element')
        ]);

        if ($property) {

            return redirect()->route('properties');
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function propertyDelete($id)
    {
        Property::where('id', $id)->delete();
        
        return redirect()->route('properties');
    }
}
