<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Image;
use App\Models\Product;
use App\Models\Property;
use App\Services\FileService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminProductController extends Controller
{
    public function products()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }
        
        $categories = Category::all();
        $properties = Property::all();
        $products = Product::latest()->get();

        return view('admin.products', ['products' => $products, 'properties' => $properties, 'categories' => $categories]);
    }

    public function productInsert(Request $request)
    {
        $path = FileService::uploadFile($request->file('image'));

        $product = Product::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'price' => $request->input('price'),
            'count' => $request->input('count'),
            'category_id' => $request->input('category')
        ]);

        if ($product) {
            foreach (Property::all() as $property) {
                $product->valueproperties()->attach($request->input($property->element));
            }

            $image = Image::create([
                'name' =>$path,
                'product_id' => $product->id
            ]);

            if ($product && $image) {
                return redirect()->route('products');
            }
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function productUpdate(Request $request, $id)
    {
        $product = Product::where('id', $id)->first();

        $path = FileService::updateFile($request->file('image'), $product->images[0]->name);

        $product = $product->update([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'price' => $request->input('price'),
            'count' => $request->input('count'),
            'category_id' => $request->input('category')
        ]);

        if ($product) {
            foreach (Property::all() as $property) {
                $product->valueproperties()->sync($request->input($property->element));
            }

            $image = Image::create([
                'name' =>$path,
                'product_id' => $product->id
            ]);

            if ($product && $image) {
                return redirect()->route('products');
            }
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function productDelete($id)
    {
        $product = Product::where('id', $id)->first();

        FileService::deleteFile($product->images[0]->name);
        $product->delete();

        return redirect()->route('products');
    }
}
