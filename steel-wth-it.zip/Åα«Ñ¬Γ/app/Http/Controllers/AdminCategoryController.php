<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminCategoryController extends Controller
{
    public function categories()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }

        $categories = Category::all();

        return view('admin.categories', ['categories' => $categories]);
    }

    public function categoryInsert(Request $request)
    {
        $categories = Category::all();

        foreach ($categories as $category) {
            if ($category->name == $request->input('name')) {
                return back()->withErrors([
                    'error' => 'Данная категория уже существует!'
                ]);
            }
        }

        $category = Category::create([
            'name' => $request->input('name')
        ]);

        if ($category) {
            return redirect()->route('categories');
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function categoryUpdate(Request $request, $id)
    {
        $categories = Category::all();

        foreach ($categories as $category) {
            if ($category->name == $request->input('name')) {
                return back()->withErrors([
                    'error' => 'Данная категория уже существует!'
                ]);
            }
        }
        
        $category = Category::where('id', $id)->update([
            'name' => $request->input('name')
        ]);

        if ($category) {
            return redirect()->route('categories');
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function categoryDelete($id)
    {
        Category::where('id', $id)->delete();

        return redirect()->route('categories');
    }
}
