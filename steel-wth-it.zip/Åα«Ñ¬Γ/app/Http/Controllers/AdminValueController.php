<?php

namespace App\Http\Controllers;

use App\Models\Property;
use App\Models\ValueProperty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminValueController extends Controller
{
    public function values($property_id)
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }

        $property = Property::where('id', $property_id)->first();

        return view('admin.values', ['property' => $property]);
    }

    public function valueInsert(Request $request, $property_id)
    {
        $valueproperties = ValueProperty::all();

        foreach ($valueproperties as $valueproperty) {
            if ($valueproperty->value == $request->input('value')) {
                return back()->withErrors([
                    'error' => 'Данная категория уже существует!'
                ]);
            }
        }

        $valueproperty = ValueProperty::create([
            'value' => $request->input('value'),
            'property_id' => $property_id
        ]);

        if ($valueproperty) {
            return redirect()->route('values', $property_id);
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function valueUpdate(Request $request, $property_id, $id)
    {
        $valueproperties = ValueProperty::all();

        foreach ($valueproperties as $valueproperty) {
            if ($valueproperty->value == $request->input('value')) {
                return back()->withErrors([
                    'error' => 'Данная категория уже существует!'
                ]);
            }
        }
        
        $valueproperty = ValueProperty::where('id', $id)->update([
            'value' => $request->input('value'),
            'property_id' => $property_id
        ]);

        if ($valueproperty) {
            return redirect()->route('values', $property_id);
        }

        return back()->withErrors([
            'error' => 'Ошибка!'
        ]);
    }

    public function valueDelete($property_id, $id)
    {
        ValueProperty::where('id', $id)->delete();

        return redirect()->route('values', $property_id);
    }
}
