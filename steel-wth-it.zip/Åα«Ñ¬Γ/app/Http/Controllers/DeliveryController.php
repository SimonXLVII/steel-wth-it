<?php

namespace App\Http\Controllers;

use App\Models\Address;
use Illuminate\Http\Request;

class DeliveryController extends Controller
{
    public function index()
    {
        $addresses = Address::all();

        return view('delivery.index', ['addresses' => $addresses]);
    }
}
