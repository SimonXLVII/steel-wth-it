<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function register()
    {
        if (Auth::user())
        {
            return redirect()->route('index');
        }
        
        return view('auth.register');
    }

    public function registerStore(Request $request)
    {
        if (Auth::attempt($request->only(['email', 'password']))) {
            return back()->withErrors([
                'errorRegister' => 'Пользователь уже существует'
            ]);
        }

        $user = User::create([
            'name' => $request->input('name'),
            'phone' => $request->input('phone'),
            'email' => $request->input('email'),
            'password' => Hash::make($request->input('password')),
            'rules' => true,
            'role_id' => 1,
        ]);

        if ($user) {
            Auth::login($user);
            return redirect()->route('index');
        }

        return back()->withErrors([
            'errorRegister' => 'Пользователь уже существует'
        ]);
    }
}
