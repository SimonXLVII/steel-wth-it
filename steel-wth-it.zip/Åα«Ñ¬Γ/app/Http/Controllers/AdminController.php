<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index()
    {
        if (!Auth::user() || auth()->user()->role_id != 2) {
            return redirect()->route('index');
        }

        return view('admin.index');
    }
}
