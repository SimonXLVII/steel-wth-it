<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Property;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index($id)
    {
        $product = Product::where('id', $id)->first();

        if ($product->count == 0) {
            return redirect()->route('index');
        }

        $categories = Category::all();
        $properties = Property::all();

        return view('product.index', ['product' => $product, 'categories' => $categories, 'properties' => $properties]);
    }
}
