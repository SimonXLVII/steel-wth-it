<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'price',
        'count',
        'category_id'
    ];

    public function images()
    {
        return $this->hasMany(Image::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function baskets()
    {
        return $this->hasMany(Basket::class);
    }

    public function orderproducts()
    {
        return $this->hasMany(OrderProduct::class);
    }

    public function valueproperties()
    {
        return $this->belongsToMany(ValueProperty::class, 'product_value_properties');
    }
}
