<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ValueProperty extends Model
{
    use HasFactory;
    
    public $timestamps = false;
    protected $fillable = [
        'value',
        'property_id'
    ];

    public function property()
    {
        return $this->belongsTo(Property::class);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_value_properties');
    }
}
