<?php

use App\Http\Controllers\AboutController;
use App\Http\Controllers\AdminCategoryController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminOrdersController;
use App\Http\Controllers\AdminProductController;
use App\Http\Controllers\AdminPropertyController;
use App\Http\Controllers\AdminValueController;
use App\Http\Controllers\BasketController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\ContactsController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [MainController::class, 'index'])->name('index');

Route::get('/about', [AboutController::class, 'index'])->name('about');
Route::get('/contacts', [ContactsController::class, 'index'])->name('contacts');
Route::get('/delivery', [DeliveryController::class, 'index'])->name('delivery');

Route::get('/catalog', [CatalogController::class, 'catalog'])->name('catalog');
Route::get('/catalog/{category}', [CatalogController::class, 'category'])->name('category');

Route::get('/basket', [BasketController::class, 'index'])->name('basket');
Route::get('/basket/{id}', [BasketController::class, 'basketAdd'])->name('basket.add');

Route::get('/register', [RegisterController::class, 'register'])->name('register');
Route::post('/register', [RegisterController::class, 'registerStore'])->name('register.store');

Route::get('/login', [LoginController::class, 'login'])->name('login');
Route::post('/login', [LoginController::class, 'loginCheck'])->name('login.check');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
Route::get('/profile/order', [ProfileController::class, 'order'])->name('profile.order');

Route::get('/admin', [AdminController::class, 'index'])->name('admin');

Route::get('/admin/categories', [AdminCategoryController::class, 'categories'])->name('categories');
Route::post('/admin/categories', [AdminCategoryController::class, 'categoryInsert'])->name('category.insert');
Route::post('/admin/categories/update/{id}', [AdminCategoryController::class, 'categoryUpdate'])->name('category.update');
Route::get('/admin/categories/delete/{id}', [AdminCategoryController::class, 'categoryDelete'])->name('category.delete');

Route::get('/admin/products', [AdminProductController::class, 'products'])->name('products');
Route::post('/admin/products', [AdminProductController::class, 'productInsert'])->name('product.insert');
Route::post('/admin/products/update/{id}', [AdminProductController::class, 'productUpdate'])->name('product.update');
Route::get('/admin/products/delete/{id}', [AdminProductController::class, 'productDelete'])->name('product.delete');

Route::get('/admin/properties', [AdminPropertyController::class, 'properties'])->name('properties');
Route::post('/admin/properties', [AdminPropertyController::class, 'propertyInsert'])->name('property.insert');
Route::post('/admin/properties/update/{id}', [AdminPropertyController::class, 'propertyUpdate'])->name('property.update');
Route::get('/admin/properties/delete/{id}', [AdminPropertyController::class, 'propertyDelete'])->name('property.delete');

Route::get('/admin/values/{values}', [AdminValueController::class, 'values'])->name('values');
Route::post('/admin/values/{values}', [AdminValueController::class, 'valueInsert'])->name('value.insert');
Route::post('/admin/values/{values}/update/{id}', [AdminValueController::class, 'valueUpdate'])->name('value.update');
Route::get('/admin/values/{values}/delete/{id}', [AdminValueController::class, 'valueDelete'])->name('value.delete');

Route::get('/admin/orders', [AdminOrdersController::class, 'orders'])->name('admin.orders');
Route::get('/admin/order', [AdminOrdersController::class, 'order'])->name('admin.order');

Route::get('/{product}', [ProductController::class, 'index'])->name('product');