let rules = document.querySelector('#rules');

rules.addEventListener('change', function() {
    if (rules.checked == false) {
        rules.checked = true;
    }
});