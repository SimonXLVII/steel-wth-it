let password = document.querySelector('#password'),
    password_confirmation = document.querySelector('#password_confirmation');

password.addEventListener('change', function() {
    let value = password.value;
    password_confirmation.value = value;
});

password_confirmation.addEventListener('change', function() {
    let value = password.value;
    password_confirmation.value = value;
});