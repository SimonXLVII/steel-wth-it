let year = document.querySelector('.year'),
    curr_year = new Date().getFullYear();

year.innerText = "@STI 2001-"+curr_year;