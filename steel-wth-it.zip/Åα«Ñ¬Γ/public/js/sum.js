let input_prices = document.querySelectorAll('#price'),
    input_counts = document.querySelectorAll('#count'),
    input_sums = document.querySelectorAll('#sum');

for (let i = 0; i < input_sums.length; i++) {
    input_sums[i].value = input_counts[i].value * input_prices[i].value;
    input_sums[i].setAttribute("min", input_sums[i].value);
    input_sums[i].setAttribute("max", input_sums[i].value);
}

input_counts.forEach(input_count => {
    input_count.addEventListener('change', function() {
        for (let i = 0; i < input_sums.length; i++) {
            input_sums[i].value = input_counts[i].value * input_prices[i].value;
            input_sums[i].setAttribute("min", input_sums[i].value);
            input_sums[i].setAttribute("max", input_sums[i].value);
        }
    });
});