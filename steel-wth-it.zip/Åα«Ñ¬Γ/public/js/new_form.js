let items_new = document.querySelectorAll('.item_new'),
    new_forms = document.querySelectorAll('.new_form');

for (let index = 0; index < items_new.length; index++) {
    items_new[index].addEventListener('click', function() {
        if (new_forms[index].style.display == 'none') {
            new_forms[index].style.display = 'flex';
        } else {
            new_forms[index].style.display = 'none';
        }
    });
}