let options = document.querySelectorAll('option');

for (let index = 0; index < options.length; index++) {

    if (index < options.length-1 && options[index].value == options[index+1].value) {
        options[index+1].remove();
    }
}