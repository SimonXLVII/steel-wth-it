let nav = document.querySelector('nav'),
    header_menu_items = document.querySelectorAll('.header_menu_item');

let footer = document.querySelector('footer'),
    footer_menu_items = document.querySelectorAll('.footer_menu_item');

nav.addEventListener('mouseover', function() {
    header_menu_items.forEach(header_menu_item => {
        header_menu_item.style.color = 'black';
    });
});
nav.addEventListener('mouseout', function() {
    header_menu_items.forEach(header_menu_item => {
        header_menu_item.style.color = 'white';
    });
});

footer.addEventListener('mouseover', function() {
    footer_menu_items.forEach(footer_menu_item => {
        footer_menu_item.style.color = 'black';
    });
});
footer.addEventListener('mouseout', function() {
    footer_menu_items.forEach(footer_menu_item => {
        footer_menu_item.style.color = 'white';
    });
});