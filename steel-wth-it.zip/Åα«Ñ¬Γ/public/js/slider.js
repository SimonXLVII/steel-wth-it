let slides = document.querySelectorAll('.slide');

slides[0].style.opacity = 1;
let i = 0;

setInterval(() => {
    if (i == 0) {
        slides[slides.length-1].style.opacity = 0;
        slides[i].style.opacity = 1;
    } else if (i > 0 && i < (slides.length-1)) {
        slides[i-1].style.opacity = 0;
        slides[i].style.opacity = 1;
    } else {
        slides[i-1].style.opacity = 0;
        slides[i].style.opacity = 1;

        i = -1;
    }

    i++;
}, 3000);


