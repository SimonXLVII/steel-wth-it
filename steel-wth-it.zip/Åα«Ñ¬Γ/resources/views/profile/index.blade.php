@extends('layouts.app')

@section('title', auth()->user()->name)
@section('h1', auth()->user()->name)
@section('content')
    <div class="profile">
        <table>
            <tr>
                <td>Номер заказа</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
                <td>Статус</td>
                <td>Подробно</td>
            </tr>
            <tr>
                <td>
                    1
                </td>
                <td>
                    6
                </td>
                <td>
                    1200
                </td>
                <td>
                    Новый
                </td>
                <td>
                    <a href="{{route('profile.order')}}" class="form_btn">Подробно</a>
                </td>
            </tr>
        </table>
    </div>
@endsection