@extends('layouts.app')

@section('title', 'Каталог')
@section('h1', 'Каталог')

@section('content')
    <div class="catalog">
        @foreach ($categories as $category)
            <a href="{{route('category', $category->id)}}" class="card">
                <img src="storage/{{$category->products[0]->images[0]->name}}" alt="{{$category->products[0]->images[0]->name}}" class="card_img">
                <p>{{$category->name}}</p>
            </a>
        @endforeach
    </div>
@endsection