@extends('layouts.app')

@section('title', $category->name)
@section('h1', $category->name)

@section('content')
    <div class="category">
        @if (count($category->products) == 0)
            <p class="message">Товары данной категории отсутствуют!</p>
        @else
            @foreach ($category->products as $product)
                @if ($product->count)
                    <a href="{{route('product', $product->id)}}" class="card">
                        <img src="/storage/{{$product->images[0]->name}}" alt="{{$product->images[0]->name}}" class="card_img">
                        <p>{{$product->name}}</p>
                        <p class="card_price">{{$product->price}} ₽</p>
                    </a>
                @endif
            @endforeach
        @endif
    </div>
@endsection