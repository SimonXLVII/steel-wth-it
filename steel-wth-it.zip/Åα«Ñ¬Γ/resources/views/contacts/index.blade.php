@extends('layouts.app')

@section('title', 'Контакты')
@section('h1', 'Контакты')

@section('content')
    <div class="contacts">
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2278.0488664056425!2d61.39824769029039!3d55.182415072298475!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x43c5ed25a96338c7%3A0x126edc1c106b30c2!2z0YPQuy4g0JrQuNGA0L7QstCwLCAxLCDQp9C10LvRj9Cx0LjQvdGB0LosINCn0LXQu9GP0LHQuNC90YHQutCw0Y8g0L7QsdC7LiwgNDU0MDg0!5e0!3m2!1sru!2sru!4v1650941180771!5m2!1sru!2sru" allowfullscreen="" loading="eager" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <p >Адрес: ул. Кирова, 1, Челябинск</p>
        <a href="tel:+">Тел.: +7-(800)-555-35-35</a>
        <a href="mailto:">Почта: sti@mail.ru</a>
    </div>
@endsection