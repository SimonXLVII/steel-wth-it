<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="shortcut icon" href="{{asset('storage/favicon.png')}}" type="image/png">
    <link rel="stylesheet" href="{{asset('css/global.css')}}">
    <link rel="stylesheet" href="{{asset('css/section.css')}}">
    <link rel="stylesheet" href="{{asset('css/header.css')}}">
    <link rel="stylesheet" href="{{asset('css/contacts.css')}}">
    <link rel="stylesheet" href="{{asset('css/admin_categories.css')}}">
    <link rel="stylesheet" href="{{asset('css/admin_products.css')}}">
    <link rel="stylesheet" href="{{asset('css/admin_properties.css')}}">
    <link rel="stylesheet" href="{{asset('css/admin_orders.css')}}">
    <link rel="stylesheet" href="{{asset('css/main.css')}}">
    <link rel="stylesheet" href="{{asset('css/admin.css')}}">
    <link rel="stylesheet" href="{{asset('css/profile.css')}}">
    <link rel="stylesheet" href="{{asset('css/delivery.css')}}">
    <link rel="stylesheet" href="{{asset('css/catalog.css')}}">
    <link rel="stylesheet" href="{{asset('css/category.css')}}">
    <link rel="stylesheet" href="{{asset('css/register.css')}}">
    <link rel="stylesheet" href="{{asset('css/login.css')}}">
    <link rel="stylesheet" href="{{asset('css/product.css')}}">
    <link rel="stylesheet" href="{{asset('css/basket.css')}}">
    <link rel="stylesheet" href="{{asset('css/card.css')}}">
    <link rel="stylesheet" href="{{asset('css/slider.css')}}">
    <link rel="stylesheet" href="{{asset('css/about.css')}}">
    <link rel="stylesheet" href="{{asset('css/new_form.css')}}">
    <link rel="stylesheet" href="{{asset('css/footer.css')}}">
</head>
<body>
    <header>
        <nav>
            <a href="{{route('index')}}" class="header_menu_item">STI</a>
            @if (auth()->user() && auth()->user()->role_id == 2)
                <a href="{{route('categories')}}" class="header_menu_item">Категории</a>
                <a href="{{route('products')}}" class="header_menu_item">Товары</a>
                <a href="{{route('properties')}}" class="header_menu_item">Характеристики</a>
                <a href="{{route('admin.orders')}}" class="header_menu_item">Заказы</a>
            @else
                <a href="{{route('catalog')}}" class="header_menu_item">Каталог</a>
                <a href="{{route('delivery')}}" class="header_menu_item">Доставка</a>
                <a href="{{route('about')}}" class="header_menu_item">О нас</a>
                <a href="{{route('contacts')}}" class="header_menu_item">Контакты</a>
            @endif
            @guest
                <a href="{{route('login')}}" class="header_menu_item">Вход</a>
            @endguest
            @auth
                @if (auth()->user()->role_id == 2)
                    <a href="{{route('admin')}}" class="header_menu_item">{{auth()->user()->name}}</a>
                @else
                    <a href="{{route('basket')}}" class="header_menu_item">Корзина</a>
                    <a href="{{route('profile')}}" class="header_menu_item">{{auth()->user()->name}}</a>
                @endif
                <a href="{{route('logout')}}" class="header_menu_item">Выход</a>
            @endauth
        </nav>
    </header>

    <section>
        <h1>@yield('h1')</h1>
        @yield('content')
    </section>
    
    <footer>
        <span class="footer_menu_item year"></span>
        <span class="footer_menu_item">Ул. Кирова, 1, Челябинск</span>
        <a href="tel:+" class="footer_menu_item">+7-(800)-555-35-35</a>
        <a href="mailto:" class="footer_menu_item">sti@mail.ru</a>
    </footer>

    <script src="{{asset('js/menu.js')}}"></script>
    <script src="{{asset('js/year.js')}}"></script>
</body>
</html>