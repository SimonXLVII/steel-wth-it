@extends('layouts.app')

@section('title', 'Авторизация')
@section('h1', 'Авторизация')

@section('content')
    <form action="{{route('login.check')}}" method="POST" enctype="multipart/form-data" class="log">
        @csrf
            @error('errorLogin')
                <p><small class="text-danger">{{$message}}</small></p>                    
            @enderror

            <label for="email">Почта</label>
            <input type="email" id="email" name="email" class="log_email" value="{{old('email')}}" required>

            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" class="log_password" value="" required>

        <button type="submit" id="log_submit" name="log_submit" class="log_submit">Авторизоваться</button>
    </form>

    <a href="{{route('register')}}" class="log_link">Нет аккаунта? Welcome пожаловать!</a>
@endsection