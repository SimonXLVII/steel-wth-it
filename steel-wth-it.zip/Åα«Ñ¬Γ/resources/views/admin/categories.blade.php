@extends('layouts.app')

@section('title', 'Админ-панель: Категории')
@section('h1', 'Админ-панель: Категории')

@section('content')
    <div class="admin_categories">

        @error('error')
            <p>{{$message}}</p>                    
        @enderror
        
        <span class="item_new">Новая категория</span>
        <form action="{{route('category.insert')}}" method="post" class="new_form" style="display: none;">
            @csrf
                <label for="name">Название категории</label>
                <input type="text" id="name" name="name" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>

        <table>
            <tr>
                <td>Название категории</td>
                <td>Изменить/удалить</td>
            </tr>
            @foreach ($categories as $category)
                <tr>
                    <form action="{{route('category.update', $category->id)}}" method="post">
                        @csrf
                            <td>
                                <input type="text" id="name" name="name" value="{{$category->name}}" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>
                            </td>
                            <td>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="{{route('category.delete', $category->id)}}" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            @endforeach
        </table>
    </div>

    <script src="{{asset('js/new_form.js')}}"></script>
@endsection