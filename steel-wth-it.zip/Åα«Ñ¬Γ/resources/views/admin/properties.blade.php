@extends('layouts.app')

@section('title', 'Админ-панель: Характеристики')
@section('h1', 'Админ-панель: Характеристики')

@section('content')
    <div class="admin_properties">

        @error('error')
            <p>{{$message}}</p>                    
        @enderror
        
        <span class="item_new">Новая характеристика</span>
        <form action="{{route('property.insert')}}" method="post" class="new_form form_props" style="display: none;">
            @csrf
                <label for="name">Название характеристики</label>
                <input type="text" id="name" name="name" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>

                <label for="element">Тег характеристики</label>
                <input type="text" id="element" name="element" pattern="^[a-z]{1,20}$" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>
        
        <table>
            <tr>
                <td>Название характеристики</td>
                <td>Тег характеристики</td>
                <td>Изменить/удалить</td>
            </tr>
            @foreach ($properties as $property)
                <tr>
                    <form action="{{route('property.update', $property->id)}}" method="post">
                        @csrf
                            <td>
                                <input type="text" id="name" name="name" value="{{$property->name}}" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>
                            </td>
                            <td>
                                <input type="text" id="element" name="element" value="{{$property->element}}" pattern="^[a-z]{1,20}$" required>
                            </td>
                            <td>
                                <a href="{{route('values', $property->id)}}" class="form_btn">Значения</a>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="{{route('property.delete', $property->id)}}" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            @endforeach
        </table>
    </div>

    <script src="{{asset('js/new_form.js')}}"></script>
@endsection