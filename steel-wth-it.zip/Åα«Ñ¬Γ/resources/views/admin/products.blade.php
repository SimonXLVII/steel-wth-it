@extends('layouts.app')

@section('title', 'Админ-панель: Продукты')
@section('h1', 'Админ-панель: Продукты')

@section('content')
    <div class="admin_products">

        @error('error')
            <p>{{$message}}</p>                    
        @enderror
        
        <span class="item_new">Новый товар</span>
        <form action="{{route('product.insert')}}" method="post" enctype="multipart/form-data" class="new_form" style="display: none;">
            @csrf
                <label for="name">Название товара (кириллица, латиница, пробелы и тире)</label>
                <input type="text" id="name"  name="name" required>
                
                <label for="description">Описание товара</label>
                <textarea name="description" id="description" minlength="50" maxlength="255" rows="5" required></textarea>

                <label for="image">Изображение товара</label>
                <input type="file" name="image" id="image" accept="image/jpeg, image/jpg, image/png" required>

                <label for="category">Категория товара</label>
                <select id="category" name="category">
                    @foreach ($categories as $category)
                        <option value="{{$category->id}}">{{$category->name}}</option>
                    @endforeach
                </select>

                @foreach ($properties as $property)
                    <label for="{{$property->element}}">{{$property->name}}</label>
                    <select id="{{$property->element}}" name="{{$property->element}}">
                        @foreach ($property->valueproperties as $valueproperty)
                            <option value="{{$valueproperty->id}}">{{$valueproperty->value}}</option>
                        @endforeach
                    </select>
                @endforeach

                <label for="count">Количество товара</label>
                <input type="number" id="count"  name="count" min="1" max="20" value="20" required>

                <label for="price">Цена товара</label>
                <input type="number" id="price"  name="price" min="100" max="2000" value="100" required>

                <button type="submit" class="form_btn">Добавить</button>
        </form>

        <table>
            <tr>
                <td>Название товара</td>
                <td>Категория товара</td>
                <td>Количество товара, шт</td>
                <td>Цена товара, ₽</td>
                <td>Подробная информация</td>
            </tr>
            @foreach ($products as $product)
                <tr>
                    <td class="img_name">
                        <img src="/storage/{{$product->images[0]->name}}" alt="{{$product->images[0]->name}}">
                        {{$product->name}}
                    </td>
                    <td>{{$product->category->name}}</td>
                    <td>{{$product->count}}</td>
                    <td>{{$product->price}}</td>
                    <td>
                        <a href="{{route('product', $product->id)}}" class="form_btn">Подробнее</a>
                    </td>
                </tr>
            @endforeach
        </table>
    </div>

    <script src="{{asset('js/new_form.js')}}"></script>
@endsection