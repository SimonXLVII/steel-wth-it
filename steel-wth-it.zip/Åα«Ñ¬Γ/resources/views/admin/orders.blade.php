@extends('layouts.app')

@section('title', 'Админ-панель: Заказы')
@section('h1', 'Админ-панель: Заказы')

@section('content')
    <div class="admin_orders">
        <table>
            <tr>
                <td>Номер заказа</td>
                <td>Имя заказчика</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
                <td>Статус</td>
                <td>Подробно</td>
            </tr>
            <tr>
                <td>
                    1
                </td>
                <td>
                    Пользователь
                </td>
                <td>
                    6
                </td>
                <td>
                    1200
                </td>
                <td>
                    <select name="" id="">
                        @foreach ($statuses as $status)
                            <option value="">{{$status->name}}</option>
                        @endforeach
                    </select>
                </td>
                <td>
                    <a href="{{route('admin.order')}}" class="form_btn">Подробно</a>
                </td>
            </tr>
        </table>
    </div>

    <script src="{{asset('js/new_form.js')}}"></script>
@endsection