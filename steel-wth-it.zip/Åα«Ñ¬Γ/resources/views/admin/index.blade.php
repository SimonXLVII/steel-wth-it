@extends('layouts.app')

@section('title', 'Админ-панель')
@section('h1', 'Админ-панель')

@section('content')
    <div class="admin">
        <a href="{{route('categories')}}" class="admin_link">Категории</a>

        <a href="{{route('products')}}" class="admin_link">Товары</a>
        
        <a href="{{route('properties')}}" class="admin_link">Характеристики</a>

        <a href="{{route('admin.orders')}}" class="admin_link">Заказы</a>
    </div>
@endsection