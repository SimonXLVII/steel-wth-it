@extends('layouts.app')

@section('title', 'Заказ №1')
@section('h1', 'Заказ №1')
@section('content')
    <div class="profile">
        <table>
            <tr>
                <td>Название товара</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
            </tr>
            <tr>
                <td>
                    ЯЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    200
                </td>
            </tr>
            <tr>
                <td>
                    ДЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    200
                </td>
            </tr>
            <tr>
                <td>
                    ЮЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    800
                </td>
            </tr>
        </table>
    </div>
@endsection