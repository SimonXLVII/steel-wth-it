@extends('layouts.app')

@section('title', 'Админ-панель: '.$property->name)
@section('h1', 'Админ-панель: '.$property->name)

@section('content')
    <div class="admin_properties">

        @error('error')
            <p>{{$message}}</p>                    
        @enderror
        
        <span class="item_new">Новая значение</span>
        <form action="{{route('value.insert', $property->id)}}" method="post" class="new_form" style="display: none;">
            @csrf
                <label for="value">Значение (значение+пробел+ед. измерения)</label>
                <input type="text" id="value" name="value" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>
        
        <table>
            <tr>
                <td>Значение</td>
                <td>Изменить/удалить</td>
            </tr>
            @foreach ($property->valueproperties as $valueproperty)
                <tr>
                    <form action="{{route('value.update', [$property->id, $valueproperty->id])}}" method="post">
                        @csrf
                            <td>
                                <input type="text" id="value" name="value" value="{{$valueproperty->value}}" required>
                            </td>
                            <td>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="{{route('value.delete', [$property->id, $valueproperty->id])}}" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            @endforeach
        </table>
    </div>

    <script src="{{asset('js/new_form.js')}}"></script>
@endsection