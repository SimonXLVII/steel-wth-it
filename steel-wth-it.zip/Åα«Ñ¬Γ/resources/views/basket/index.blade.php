@extends('layouts.app')

@section('title', 'Корзина')
@section('h1', 'Корзина')

@section('content')
    @if (count($baskets) == 0)
        <p class="message">Корзина пуста!</p>
    @else
        <div class="basket">
            <div class="basket_head">
                <span>Название</span>
                <span>Цена, ₽</span>
                <span>Количество, шт</span>
                <span>Сумма, ₽</span>
            </div>

            <form action="#" method="POST" enctype="multipart/form-data">
                @csrf
                    @foreach ($baskets as $basket)
                        <div class="basket_body">
                            <a href="{{route('product', $basket->product->id)}}" class="basket_content">{{$basket->product->name}}</a>

                            <span>{{$basket->product->price}}</span>

                            <input type="number" id="count" name="count" min="0" max="{{$basket->count}}" value="{{$basket->count}}">

                            <span>{{$basket->product->price * $basket->count}}</span>
                        </div>
                    @endforeach

                    <div class="basket_btn">
                        <button type="submit" id="submit" name="submit" class="basket_submit">Оформить заказ</button>
                    </div>
            </form>
        </div>
    @endif
@endsection