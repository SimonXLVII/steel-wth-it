@extends('layouts.app')

@section('title', 'О нас')
@section('h1', 'О нас')

@section('content')
        <div class="about">
            <p>STI - Магазин для тебя!</p>
            <div class="slider">
                <img src="storage/slide1.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide2.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide3.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide4.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide5.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
            </div>
            <p class="about_descr">
                Компания &laquo;STEEL WTH IT&raquo;, или &laquo;STI&raquo;, занимается продажей уникальных цепочек
                различного типа плетения, цвет и материала. Отличительной особенностью является то, что все цепи производит
                непосредственно компания, за счёт чего обеспечивает своих клиентов уникальной атрибутикой, подчёркивающий особенность
                и отвечающий запросам каждого из покупателей.
            </p>
            <p class="about_descr">
                &laquo;STI&raquo; - у нас то найдёшь, что ты искал!
            </p>
        </div>

    <script src="{{asset('js/slider.js')}}"></script>
@endsection