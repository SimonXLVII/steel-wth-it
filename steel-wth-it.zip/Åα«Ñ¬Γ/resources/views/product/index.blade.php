@extends('layouts.app')

@section('title', $product->name)
@section('h1', $product->name)

@section('content')
    <div class="product">
        @if (auth()->user() && auth()->user()->role_id == 2)
            <form action="{{route('product.update', $product->id)}}" method="post" class="new_form">
                @csrf
                    <label for="name">Название товара</label>
                    <input type="text" id="name"  name="name" value="{{$product->name}}" pattern="^[А-Яа-яЁёA-Za-z\s-]{1,20}$" required>
                    
                    <label for="description">Описание товара</label>
                    <textarea name="description" id="description" minlength="50" maxlength="255" rows="5" required>{{$product->description}}</textarea>

                    <label for="image" class="filename">Изображение товара по умолчанию: {{$product->images[0]->name}}</label>
                    <input type="file" name="image" id="image" accept="image/jpeg, image/jpg, image/png">

                    <label for="category">Категория товара</label>
                    <select id="category" name="category">
                        @foreach ($categories as $category)
                            @if ($product->category_id == $category->id)
                                <option value="{{$category->id}}" selected>{{$category->name}}</option>
                            @else
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endif
                        @endforeach
                    </select>

                    @foreach ($properties as $property)
                        <label for="{{$property->element}}">{{$property->name}}</label>
                        <select id="{{$property->element}}" name="{{$property->element}}">
                            @foreach ($property->valueproperties as $prop_valueproperty)
                                @foreach ($product->valueproperties as $prod_valueproperty)
                                    @if ($prop_valueproperty->id == $prod_valueproperty->id)
                                        <option value="{{$prop_valueproperty->id}}" selected>{{$prop_valueproperty->value}}</option>
                                    @endif
                                @endforeach
                                
                                <option value="{{$prop_valueproperty->id}}">{{$prop_valueproperty->value}}</option>
                            @endforeach
                        </select>
                    @endforeach

                    <label for="count">Количество товара</label>
                    <input type="number" id="count"  name="count" min="1" max="20" value="{{$product->count}}" required>

                    <label for="price">Цена товара</label>
                    <input type="number" id="price"  name="price" min="100" max="2000" value="{{$product->price}}" required>

                    <button type="submit" class="form_btn">Изменить</button>
                    <a href="{{route('product.delete', $product->id)}}" class="form_btn">Удалить</a>
            </form>

            <script src="{{asset('js/options.js')}}"></script>
        @else
            <img src="storage/{{$product->images[0]->name}}" alt="blog">

            <div>
                <p class="description">{{$product->description}}</p>

                @foreach ($product->valueproperties as $valueproperty)
                    <p>{{$valueproperty->property->name}}: {{$valueproperty->value}}</p>
                @endforeach

                <p class="product_price">Цена: {{$product->price}} ₽</p>
                @auth
                    @if (auth()->user()->role_id == 1 && count($product->baskets) == 0)
                        <a href="{{route('basket.add', $product->id)}}" class="product_submit">В корзину</a>
                    @elseif (auth()->user()->role_id == 1 && count($product->baskets) > 0)
                        <span href="{{route('basket', $product->id)}}" class="product_submit">Товар в корзине</span>
                    @endif
                @endauth
            </div>
        @endif
    </div>
@endsection