

<?php $__env->startSection('title', auth()->user()->name); ?>
<?php $__env->startSection('h1', auth()->user()->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile">
        <table>
            <tr>
                <td>Номер заказа</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
                <td>Статус</td>
                <td>Подробно</td>
            </tr>
            <tr>
                <td>
                    1
                </td>
                <td>
                    6
                </td>
                <td>
                    1200
                </td>
                <td>
                    Новый
                </td>
                <td>
                    <a href="<?php echo e(route('profile.order')); ?>" class="form_btn">Подробно</a>
                </td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/profile/index.blade.php ENDPATH**/ ?>