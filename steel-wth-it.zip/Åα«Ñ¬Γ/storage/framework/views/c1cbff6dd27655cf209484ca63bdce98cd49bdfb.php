

<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('h1', $product->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="product">
        <?php if(auth()->user() && auth()->user()->role_id == 2): ?>
            <form action="<?php echo e(route('product.update', $product->id)); ?>" method="post" class="new_form">
                <?php echo csrf_field(); ?>
                    <label for="name">Название товара</label>
                    <input type="text" id="name"  name="name" value="<?php echo e($product->name); ?>" pattern="^[А-Яа-яЁёA-Za-z\s-]{1,20}$" required>
                    
                    <label for="description">Описание товара</label>
                    <textarea name="description" id="description" minlength="50" maxlength="255" rows="5" required><?php echo e($product->description); ?></textarea>

                    <label for="image" class="filename">Изображение товара по умолчанию: <?php echo e($product->images[0]->name); ?></label>
                    <input type="file" name="image" id="image" accept="image/jpeg, image/jpg, image/png">

                    <label for="category">Категория товара</label>
                    <select id="category" name="category">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category_id == $category->id): ?>
                                <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label for="<?php echo e($property->element); ?>"><?php echo e($property->name); ?></label>
                        <select id="<?php echo e($property->element); ?>" name="<?php echo e($property->element); ?>">
                            <?php $__currentLoopData = $property->valueproperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop_valueproperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $product->valueproperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod_valueproperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($prop_valueproperty->id == $prod_valueproperty->id): ?>
                                        <option value="<?php echo e($prop_valueproperty->id); ?>" selected><?php echo e($prop_valueproperty->value); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <option value="<?php echo e($prop_valueproperty->id); ?>"><?php echo e($prop_valueproperty->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <label for="count">Количество товара</label>
                    <input type="number" id="count"  name="count" min="1" max="20" value="<?php echo e($product->count); ?>" required>

                    <label for="price">Цена товара</label>
                    <input type="number" id="price"  name="price" min="100" max="2000" value="<?php echo e($product->price); ?>" required>

                    <button type="submit" class="form_btn">Изменить</button>
                    <a href="<?php echo e(route('product.delete', $product->id)); ?>" class="form_btn">Удалить</a>
            </form>

            <script src="<?php echo e(asset('js/options.js')); ?>"></script>
        <?php else: ?>
            <img src="storage/<?php echo e($product->images[0]->name); ?>" alt="blog">

            <div>
                <p class="description"><?php echo e($product->description); ?></p>

                <?php $__currentLoopData = $product->valueproperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueproperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($valueproperty->property->name); ?>: <?php echo e($valueproperty->value); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <p class="product_price">Цена: <?php echo e($product->price); ?> ₽</p>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role_id == 1 && count($product->baskets) == 0): ?>
                        <a href="<?php echo e(route('basket.add', $product->id)); ?>" class="product_submit">В корзину</a>
                    <?php elseif(auth()->user()->role_id == 1 && count($product->baskets) > 0): ?>
                        <span href="<?php echo e(route('basket', $product->id)); ?>" class="product_submit">Товар в корзине</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/product/index.blade.php ENDPATH**/ ?>