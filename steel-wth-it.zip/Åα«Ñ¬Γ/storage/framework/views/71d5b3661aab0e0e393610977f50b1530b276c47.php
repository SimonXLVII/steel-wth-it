

<?php $__env->startSection('title', 'Регистрация'); ?>
<?php $__env->startSection('h1', 'Регистрация'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('register.store')); ?>" method="POST" enctype="multipart/form-data" class="reg">
        <?php echo csrf_field(); ?>
            <?php $__errorArgs = ['errorRegister'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><small class="text-danger"><?php echo e($message); ?></small></p>                    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="name">Имя (1-20 символов - кириллица, пробел, тире)</label>
            <input type="text" id="name" name="name" pattern="^[А-ЯЁ\s-]{1,20}+$/ui" class="reg_name" required>

            <label for="phone">Телефон</label>
            <input type="text" id="phone" name="phone" pattern="^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$" class="reg_phone" required>

            <label for="email">Почта</label>
            <input type="email" id="email" name="email" pattern="^[A-Z0-9\-]+@[A-Z0-9]+.(ru|com))$/i" class="reg_email" required>

            <label for="password">Пароль (6-12 символов - латиница, цифры, тире)</label>
            <input type="password" id="password" name="password" pattern="^[A-Z\d-]{6, 12}$/i" class="reg_password" required>

            <label for="password_confirmation">Повтор пароля</label>
            <input type="password" id="password_confirmation" name="password_confirmation" class="reg_password" required>

            <div class="reg_rules">
                <input type="checkbox" id="rules" name="rules" checked>
                <label for="rules">Согласие на обработку персональных данных</label>
            </div>

        <button type="submit" id="submit" name="submit" class="reg_submit">Зарегистрироваться</button>
    </form>
    
    <a href="<?php echo e(route('login')); ?>" class="reg_link">Есть аккаунт? Welcome пожаловать!</a>

    <script src="<?php echo e(asset('/js/reg.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/password_confirm.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/auth/register.blade.php ENDPATH**/ ?>