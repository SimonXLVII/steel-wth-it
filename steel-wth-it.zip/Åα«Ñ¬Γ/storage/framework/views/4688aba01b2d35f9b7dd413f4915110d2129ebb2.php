

<?php $__env->startSection('title', 'Админ-панель: Заказы'); ?>
<?php $__env->startSection('h1', 'Админ-панель: Заказы'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin_orders">
        <table>
            <tr>
                <td>Номер заказа</td>
                <td>Имя заказчика</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
                <td>Статус</td>
                <td>Подробно</td>
            </tr>
            <tr>
                <td>
                    1
                </td>
                <td>
                    Пользователь
                </td>
                <td>
                    6
                </td>
                <td>
                    1200
                </td>
                <td>
                    <select name="" id="">
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=""><?php echo e($status->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.order')); ?>" class="form_btn">Подробно</a>
                </td>
            </tr>
        </table>
    </div>

    <script src="<?php echo e(asset('js/new_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/orders.blade.php ENDPATH**/ ?>