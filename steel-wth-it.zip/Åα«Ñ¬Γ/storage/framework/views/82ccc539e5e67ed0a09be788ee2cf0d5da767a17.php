

<?php $__env->startSection('title', 'Админ-панель'); ?>
<?php $__env->startSection('h1', 'Админ-панель'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin">
        <a href="<?php echo e(route('categories')); ?>" class="admin_link">Категории</a>

        <a href="<?php echo e(route('products')); ?>" class="admin_link">Товары</a>
        
        <a href="<?php echo e(route('properties')); ?>" class="admin_link">Характеристики</a>

        <a href="<?php echo e(route('admin.orders')); ?>" class="admin_link">Заказы</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/index.blade.php ENDPATH**/ ?>