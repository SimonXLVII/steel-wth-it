

<?php $__env->startSection('title', 'Корзина'); ?>
<?php $__env->startSection('h1', 'Корзина'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($baskets) == 0): ?>
        <p class="message">Корзина пуста!</p>
    <?php else: ?>
        <div class="basket">
            <div class="basket_head">
                <span>Название</span>
                <span>Цена, ₽</span>
                <span>Количество, шт</span>
                <span>Сумма, ₽</span>
            </div>

            <form action="#" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="basket_body">
                            <a href="<?php echo e(route('product', $basket->product->id)); ?>" class="basket_content"><?php echo e($basket->product->name); ?></a>

                            <span><?php echo e($basket->product->price); ?></span>

                            <input type="number" id="count" name="count" min="0" max="<?php echo e($basket->count); ?>" value="<?php echo e($basket->count); ?>">

                            <span><?php echo e($basket->product->price * $basket->count); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="basket_btn">
                        <button type="submit" id="submit" name="submit" class="basket_submit">Оформить заказ</button>
                    </div>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/basket/index.blade.php ENDPATH**/ ?>