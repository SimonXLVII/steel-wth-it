<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('storage/favicon.png')); ?>" type="image/png">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/section.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/contacts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin_categories.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin_products.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin_properties.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin_orders.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/delivery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/catalog.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/category.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/basket.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/new_form.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
</head>
<body>
    <header>
        <nav>
            <a href="<?php echo e(route('index')); ?>" class="header_menu_item">STI</a>
            <?php if(auth()->user() && auth()->user()->role_id == 2): ?>
                <a href="<?php echo e(route('categories')); ?>" class="header_menu_item">Категории</a>
                <a href="<?php echo e(route('products')); ?>" class="header_menu_item">Товары</a>
                <a href="<?php echo e(route('properties')); ?>" class="header_menu_item">Характеристики</a>
                <a href="<?php echo e(route('admin.orders')); ?>" class="header_menu_item">Заказы</a>
            <?php else: ?>
                <a href="<?php echo e(route('catalog')); ?>" class="header_menu_item">Каталог</a>
                <a href="<?php echo e(route('delivery')); ?>" class="header_menu_item">Доставка</a>
                <a href="<?php echo e(route('about')); ?>" class="header_menu_item">О нас</a>
                <a href="<?php echo e(route('contacts')); ?>" class="header_menu_item">Контакты</a>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="header_menu_item">Вход</a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role_id == 2): ?>
                    <a href="<?php echo e(route('admin')); ?>" class="header_menu_item"><?php echo e(auth()->user()->name); ?></a>
                <?php else: ?>
                    <a href="<?php echo e(route('basket')); ?>" class="header_menu_item">Корзина</a>
                    <a href="<?php echo e(route('profile')); ?>" class="header_menu_item"><?php echo e(auth()->user()->name); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('logout')); ?>" class="header_menu_item">Выход</a>
            <?php endif; ?>
        </nav>
    </header>

    <section>
        <h1><?php echo $__env->yieldContent('h1'); ?></h1>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    
    <footer>
        <span class="footer_menu_item year"></span>
        <span class="footer_menu_item">Ул. Кирова, 1, Челябинск</span>
        <a href="tel:+" class="footer_menu_item">+7-(800)-555-35-35</a>
        <a href="mailto:" class="footer_menu_item">sti@mail.ru</a>
    </footer>

    <script src="<?php echo e(asset('js/menu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/year.js')); ?>"></script>
</body>
</html><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/layouts/app.blade.php ENDPATH**/ ?>