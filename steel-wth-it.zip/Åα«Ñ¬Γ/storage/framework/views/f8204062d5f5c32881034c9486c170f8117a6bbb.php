

<?php $__env->startSection('title', 'Админ-панель: '.$property->name); ?>
<?php $__env->startSection('h1', 'Админ-панель: '.$property->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin_properties">

        <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>                    
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <span class="item_new">Новая значение</span>
        <form action="<?php echo e(route('value.insert', $property->id)); ?>" method="post" class="new_form" style="display: none;">
            <?php echo csrf_field(); ?>
                <label for="value">Значение (значение+пробел+ед. измерения)</label>
                <input type="text" id="value" name="value" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>
        
        <table>
            <tr>
                <td>Значение</td>
                <td>Изменить/удалить</td>
            </tr>
            <?php $__currentLoopData = $property->valueproperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueproperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <form action="<?php echo e(route('value.update', [$property->id, $valueproperty->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <td>
                                <input type="text" id="value" name="value" value="<?php echo e($valueproperty->value); ?>" required>
                            </td>
                            <td>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="<?php echo e(route('value.delete', [$property->id, $valueproperty->id])); ?>" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <script src="<?php echo e(asset('js/new_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/values.blade.php ENDPATH**/ ?>