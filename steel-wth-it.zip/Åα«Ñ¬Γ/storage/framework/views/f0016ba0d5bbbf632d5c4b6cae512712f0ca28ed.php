

<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('h1', $category->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="category">
        <?php if(count($category->products) == 0): ?>
            <p class="message">Товары данной категории отсутствуют!</p>
        <?php else: ?>
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->count): ?>
                    <a href="<?php echo e(route('product', $product->id)); ?>" class="card">
                        <img src="/storage/<?php echo e($product->images[0]->name); ?>" alt="<?php echo e($product->images[0]->name); ?>" class="card_img">
                        <p><?php echo e($product->name); ?></p>
                        <p class="card_price"><?php echo e($product->price); ?> ₽</p>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/catalog/category.blade.php ENDPATH**/ ?>