

<?php $__env->startSection('title', 'Админ-панель: Характеристики'); ?>
<?php $__env->startSection('h1', 'Админ-панель: Характеристики'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin_properties">

        <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>                    
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <span class="item_new">Новая характеристика</span>
        <form action="<?php echo e(route('property.insert')); ?>" method="post" class="new_form form_props" style="display: none;">
            <?php echo csrf_field(); ?>
                <label for="name">Название характеристики</label>
                <input type="text" id="name" name="name" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>

                <label for="element">Тег характеристики</label>
                <input type="text" id="element" name="element" pattern="^[a-z]{1,20}$" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>
        
        <table>
            <tr>
                <td>Название характеристики</td>
                <td>Тег характеристики</td>
                <td>Изменить/удалить</td>
            </tr>
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <form action="<?php echo e(route('property.update', $property->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <td>
                                <input type="text" id="name" name="name" value="<?php echo e($property->name); ?>" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>
                            </td>
                            <td>
                                <input type="text" id="element" name="element" value="<?php echo e($property->element); ?>" pattern="^[a-z]{1,20}$" required>
                            </td>
                            <td>
                                <a href="<?php echo e(route('values', $property->id)); ?>" class="form_btn">Значения</a>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="<?php echo e(route('property.delete', $property->id)); ?>" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <script src="<?php echo e(asset('js/new_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/properties.blade.php ENDPATH**/ ?>