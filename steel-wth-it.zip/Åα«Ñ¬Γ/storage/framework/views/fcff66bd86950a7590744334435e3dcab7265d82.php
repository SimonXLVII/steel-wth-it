

<?php $__env->startSection('title', 'О нас'); ?>
<?php $__env->startSection('h1', 'О нас'); ?>

<?php $__env->startSection('content'); ?>
        <div class="about">
            <p>STI - Магазин для тебя!</p>
            <div class="slider">
                <img src="storage/slide1.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide2.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide3.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide4.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
                <img src="storage/slide5.jpg" alt="slide.jpg" class="slide" style="opacity: 0;">
            </div>
            <p class="about_descr">
                Компания &laquo;STEEL WTH IT&raquo;, или &laquo;STI&raquo;, занимается продажей уникальных цепочек
                различного типа плетения, цвет и материала. Отличительной особенностью является то, что все цепи произодит
                непосредственно компания, за счёт чего обеспечивает своих клиентов уникальной атрибутикой, подчёркивающий особенность
                и отвечающий запросам каждого из покупателей.
            </p>
            <p class="about_descr">
                &laquo;STI&raquo; - у нас ты найдёшь ту цепь, которую не захочешь разрывать!
            </p>
        </div>

    <script src="<?php echo e(asset('js/slider.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/about/index.blade.php ENDPATH**/ ?>