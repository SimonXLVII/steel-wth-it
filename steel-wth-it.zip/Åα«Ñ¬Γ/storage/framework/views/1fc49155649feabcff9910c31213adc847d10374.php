

<?php $__env->startSection('title', 'Каталог'); ?>
<?php $__env->startSection('h1', 'Каталог'); ?>

<?php $__env->startSection('content'); ?>
    <div class="catalog">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('category', $category->id)); ?>" class="card">
                <img src="storage/<?php echo e($category->products[0]->images[0]->name); ?>" alt="<?php echo e($category->products[0]->images[0]->name); ?>" class="card_img">
                <p><?php echo e($category->name); ?></p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/catalog/catalog.blade.php ENDPATH**/ ?>