

<?php $__env->startSection('title', 'Авторизация'); ?>
<?php $__env->startSection('h1', 'Авторизация'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('login.check')); ?>" method="POST" enctype="multipart/form-data" class="log">
        <?php echo csrf_field(); ?>
            <?php $__errorArgs = ['errorLogin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><small class="text-danger"><?php echo e($message); ?></small></p>                    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="email">Почта</label>
            <input type="email" id="email" name="email" class="log_email" value="<?php echo e(old('email')); ?>" required>

            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" class="log_password" value="" required>

        <button type="submit" id="log_submit" name="log_submit" class="log_submit">Авторизоваться</button>
    </form>

    <a href="<?php echo e(route('register')); ?>" class="log_link">Нет аккаунта? Welcome пожаловать!</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/auth/login.blade.php ENDPATH**/ ?>