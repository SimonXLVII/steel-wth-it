

<?php $__env->startSection('title', 'Админ-панель: Категории'); ?>
<?php $__env->startSection('h1', 'Админ-панель: Категории'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin_categories">

        <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>                    
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <span class="item_new">Новая категория</span>
        <form action="<?php echo e(route('category.insert')); ?>" method="post" class="new_form" style="display: none;">
            <?php echo csrf_field(); ?>
                <label for="name">Название категории</label>
                <input type="text" id="name" name="name" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>

                <button id="submit" name="submit" type="submit" class="form_btn">Добавить</button>
        </form>

        <table>
            <tr>
                <td>Название категории</td>
                <td>Изменить/удалить</td>
            </tr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <td>
                                <input type="text" id="name" name="name" value="<?php echo e($category->name); ?>" pattern="^[А-Яа-яЁё\s-]{1,20}$" required>
                            </td>
                            <td>
                                <button id="submit" name="submit" type="submit" class="form_btn">Изменить</button>
                                <a href="<?php echo e(route('category.delete', $category->id)); ?>" class="form_btn">Удалить</a>
                            </td>
                    </form>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <script src="<?php echo e(asset('js/new_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/categories.blade.php ENDPATH**/ ?>