

<?php $__env->startSection('title', 'Заказ №1'); ?>
<?php $__env->startSection('h1', 'Заказ №1'); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile">
        <table>
            <tr>
                <td>Название товара</td>
                <td>Количество товаров, шт</td>
                <td>Общая сумма, ₽</td>
            </tr>
            <tr>
                <td>
                    ЯЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    200
                </td>
            </tr>
            <tr>
                <td>
                    ДЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    200
                </td>
            </tr>
            <tr>
                <td>
                    ЮЦ-11
                </td>
                <td>
                    2
                </td>
                <td>
                    800
                </td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/profile/order.blade.php ENDPATH**/ ?>