

<?php $__env->startSection('title', 'Условия доставки'); ?>
<?php $__env->startSection('h1', 'Условия доставки'); ?>

<?php $__env->startSection('content'); ?>
    <div class="delivery">
        <p>
            Доставка оформленных заказов осуществеляется курьерской службой компании &laquo;STEEL WTH IT&raquo;
            в течение одной рабочей недели. Также клиентам предоставляется возможность выбора наиболее удобного
            пункта выдачи заказов.
        </p>
        <p>
            В данный момент клиентам доступны пунткы выдачи заказов по следующим адресам:
        </p>
        <ul>
            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($address->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <p>
            Общее количество пунктов выдачи: <?php echo e(count($addresses)); ?> шт.
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/delivery/index.blade.php ENDPATH**/ ?>