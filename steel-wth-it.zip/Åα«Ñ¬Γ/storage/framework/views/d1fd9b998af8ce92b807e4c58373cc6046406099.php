

<?php $__env->startSection('title', 'Админ-панель: Продукты'); ?>
<?php $__env->startSection('h1', 'Админ-панель: Продукты'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin_products">

        <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>                    
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <span class="item_new">Новый товар</span>
        <form action="<?php echo e(route('product.insert')); ?>" method="post" enctype="multipart/form-data" class="new_form" style="display: none;">
            <?php echo csrf_field(); ?>
                <label for="name">Название товара (кириллица, латиница, пробелы и тире)</label>
                <input type="text" id="name"  name="name" required>
                
                <label for="description">Описание товара</label>
                <textarea name="description" id="description" minlength="50" maxlength="255" rows="5" required></textarea>

                <label for="image">Изображение товара</label>
                <input type="file" name="image" id="image" accept="image/jpeg, image/jpg, image/png" required>

                <label for="category">Категория товара</label>
                <select id="category" name="category">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="<?php echo e($property->element); ?>"><?php echo e($property->name); ?></label>
                    <select id="<?php echo e($property->element); ?>" name="<?php echo e($property->element); ?>">
                        <?php $__currentLoopData = $property->valueproperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueproperty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($valueproperty->id); ?>"><?php echo e($valueproperty->value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <label for="count">Количество товара</label>
                <input type="number" id="count"  name="count" min="1" max="20" value="20" required>

                <label for="price">Цена товара</label>
                <input type="number" id="price"  name="price" min="100" max="2000" value="100" required>

                <button type="submit" class="form_btn">Добавить</button>
        </form>

        <table>
            <tr>
                <td>Название товара</td>
                <td>Категория товара</td>
                <td>Количество товара, шт</td>
                <td>Цена товара, ₽</td>
                <td>Подробная информация</td>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="img_name">
                        <img src="/storage/<?php echo e($product->images[0]->name); ?>" alt="<?php echo e($product->images[0]->name); ?>">
                        <?php echo e($product->name); ?>

                    </td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->count); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td>
                        <a href="<?php echo e(route('product', $product->id)); ?>" class="form_btn">Подробнее</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <script src="<?php echo e(asset('js/new_form.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\steel-wth-it\resources\views/admin/products.blade.php ENDPATH**/ ?>