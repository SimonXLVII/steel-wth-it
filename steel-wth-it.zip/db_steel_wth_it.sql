-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 23 2022 г., 22:03
-- Версия сервера: 8.0.24
-- Версия PHP: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `db_steel_wth_it`
--

-- --------------------------------------------------------

--
-- Структура таблицы `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `addresses`
--

INSERT INTO `addresses` (`id`, `name`) VALUES
(1, 'Ул. Первая, 1, Челябинск'),
(2, 'Ул. Вторая, 1, Челябинск'),
(3, 'Ул. Третья, 1, Челябинск');

-- --------------------------------------------------------

--
-- Структура таблицы `baskets`
--

CREATE TABLE `baskets` (
  `id` bigint UNSIGNED NOT NULL,
  `count` int NOT NULL,
  `sum` int NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Якорные цепи'),
(2, 'Декоративные цепи'),
(3, 'Ювелирные цепи');

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `name`, `product_id`) VALUES
(1, 'яц1.jpg', 10),
(2, 'дц1.jpg', 13),
(5, 'юц1.jpg', 21),
(7, 'IjnllmqfTYZdLUEnQLOtNRkGEmLonJCz7BoLcB1o.jpg', 24),
(8, 'geWnOiVdJ7bxIBZM7sQWI9pvUkzrwrgQLYI4gxzh.jpg', 25),
(9, 'cftFUOBsLi5LCYO5xP7BlWtJZdR2mqhVksXKwYyV.jpg', 26),
(10, 'fJoX7pNjSBzIQzRzR5czU8w2C2CAwB5Aqg1C9k6L.png', 27),
(11, 'brWR0u1fY2nuXmgYZffgQfoCT0d3oCkNsAnA7fbf.jpg', 28),
(12, 'eMSAmhYp7VVY7NDveiB9RMSL0BuFnZ3AQYk9gljP.jpg', 29),
(13, 'hMGGiplJS1Wz19yIebCTLIVWnPjLJKxry53QFEtQ.jpg', 30),
(14, 'CNF4SHOZEzxokm4WheXKJC57vhF9RS4K9wxqZ7P6.jpg', 31),
(15, 'VnLT4sh2X2vZ72k75vsBd2I2e1VQVvPVBcetJN5C.jpg', 32),
(17, 'FMip0jwDFMPuVWgcMR0dajEWalxq2vAY4PXOCyDr.jpg', 34);

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '00_create_categories_table', 1),
(2, '00_create_properties_table', 1),
(3, '00_create_roles_table', 1),
(4, '00_create_statuses_table', 1),
(5, '01_create_products_table', 1),
(6, '03_create_value_properties_table', 1),
(7, '04_create_product_value_properties_table', 1),
(8, '08_create_users_table', 1),
(9, '0_create_addresses_table', 1),
(10, '10_create_images_table', 1),
(11, '11_create_orders_table', 1),
(12, '12_create_baskets_table', 1),
(13, '13_create_order_products_table', 1),
(14, '14_create_abouts_table', 1),
(15, '15_create_contacts_table', 1),
(16, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` bigint UNSIGNED NOT NULL,
  `count` int NOT NULL,
  `sum` int NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `address_id` bigint UNSIGNED NOT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `order_products`
--

CREATE TABLE `order_products` (
  `id` bigint UNSIGNED NOT NULL,
  `count` int NOT NULL,
  `sum` int NOT NULL,
  `status` tinyint DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `count` int NOT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `count`, `category_id`, `created_at`, `updated_at`) VALUES
(10, 'ЯЦ-11', 'Якорная цепь стандартного плетения, имеющая характерные швы декоративного характера по центру каждого звена, сделанная из медицинской стали и подходящая твердым и уверенным в себе людям.', 100, 20, 1, NULL, NULL),
(13, 'ДЦ-21', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati accusamus eligendi placeat repudiandae, commodi sint consequuntur dicta neque voluptas at ea aut provident autem, accusantium similique harum, asperiores tenetur error!', 100, 20, 2, NULL, NULL),
(21, 'ЮЦ-31', 'Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь 1Ювелирная цепь', 400, 20, 3, '2022-06-16 02:23:46', '2022-06-16 02:23:46'),
(24, 'ЯЦ-12', 'Якорная цепь стандартного плетения, имеющая характерные швы декоративного характера по центру каждого звена, сделанная из медицинской стали и подходящая твердым и уверенным в себе людям.', 200, 20, 1, '2022-06-19 09:27:23', '2022-06-19 09:27:23'),
(25, 'ЯЦ-13', 'Якорная бесшовная цепь стандартного плетения, сделанная из бронзы и имеющая в комплексе внешний дизайн, отсылающий нас к египетским мотивам, тем самым подходящая людям утонченным, желающим подчеркнуть свой статус.', 400, 20, 1, '2022-06-19 09:30:24', '2022-06-19 09:30:24'),
(26, 'ЯЦ-14', 'Якорная цепь стандартного плетения, имеющая характерные швы декоративного характера по центру каждого звена, сделанная из серебра и подходящая почти под любой образ.', 500, 20, 1, '2022-06-19 09:34:51', '2022-06-19 09:34:51'),
(27, 'ЯЦ-15', 'Якорная цепь стандартного плетения, имеющая характерные швы декоративного характера по центру каждого звена, сделанная из серебра и подходящая твердым и уверенным в себе людям.', 500, 20, 1, '2022-06-19 09:35:48', '2022-06-19 09:35:48'),
(28, 'ДЦ-22', 'Декоративная цепь, имеющая квадратные массивные звенья, подчеркивающая силу и мужественность.', 100, 20, 2, '2022-06-19 09:37:15', '2022-06-19 09:37:15'),
(29, 'ДЦ-23', 'Декоративная цепь, имеющая форму бензопильной и подходящая любителям эксцентричного и вызывающего образа, бунтарям, бросающим вызов моде и принятым стандартам.', 700, 20, 2, '2022-06-19 09:39:44', '2022-06-19 09:39:44'),
(30, 'ДЦ-24', 'Декоративная цепь, имеющая нетипичное плетения из якорных звеньев, соединенных по одной общей оси, что создаёт иллюзию округленности цепочки и придает ей внешнюю массивность.', 500, 20, 2, '2022-06-19 09:41:48', '2022-06-19 09:41:48'),
(31, 'ЮЦ-32', 'Ювелирная цепь, подходящая любителям и любительницам утонченного образа и тем, кто желает подчеркнуть свой статус, свою успешность и просто людям, желающим выделить себя красивым украшением.', 700, 20, 3, '2022-06-19 09:44:02', '2022-06-19 09:44:02'),
(32, 'ЮЦ-33', 'Ювелирная цепь, подходящая любителям и любительницам утонченного образа и тем, кто желает подчеркнуть свой статус, свою успешность и просто людям, желающим выделить себя красивым украшением.', 700, 20, 3, '2022-06-19 09:44:24', '2022-06-19 09:44:24'),
(34, 'ЮЦ-34', 'Ювелирная цепь, подходящая любителям и любительницам утонченного образа и тем, кто желает подчеркнуть свой статус, свою успешность и просто людям, желающим выделить себя красивым украшением.', 700, 20, 1, '2022-06-19 09:45:04', '2022-06-19 09:45:04');

-- --------------------------------------------------------

--
-- Структура таблицы `product_value_properties`
--

CREATE TABLE `product_value_properties` (
  `product_id` bigint UNSIGNED NOT NULL,
  `value_property_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `product_value_properties`
--

INSERT INTO `product_value_properties` (`product_id`, `value_property_id`) VALUES
(10, 1),
(10, 4),
(10, 7),
(10, 10),
(13, 2),
(13, 5),
(13, 8),
(13, 11),
(21, 3),
(21, 6),
(21, 9),
(21, 12),
(24, 13),
(24, 14),
(24, 7),
(24, 10),
(25, 3),
(25, 6),
(25, 7),
(25, 11),
(26, 2),
(26, 5),
(26, 7),
(26, 10),
(27, 2),
(27, 5),
(27, 7),
(27, 11),
(28, 13),
(28, 14),
(28, 7),
(28, 10),
(29, 13),
(29, 17),
(29, 9),
(29, 12),
(30, 2),
(30, 5),
(30, 8),
(30, 11),
(31, 1),
(31, 4),
(31, 7),
(31, 10),
(32, 2),
(32, 5),
(32, 7),
(32, 10),
(34, 3),
(34, 6),
(34, 7),
(34, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `properties`
--

CREATE TABLE `properties` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `properties`
--

INSERT INTO `properties` (`id`, `name`, `element`) VALUES
(1, 'Материал', 'material'),
(2, 'Цвет', 'color'),
(3, 'Длина', 'length'),
(4, 'Вес', 'weight');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'Клиент'),
(2, 'Администратор');

-- --------------------------------------------------------

--
-- Структура таблицы `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `statuses`
--

INSERT INTO `statuses` (`id`, `name`) VALUES
(1, 'Новый'),
(2, 'В обработке'),
(3, 'Собран'),
(4, 'Отправлен'),
(5, 'Доставлен'),
(6, 'Получен'),
(7, 'Отменён');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rules` tinyint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `rules`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'Админ', '88005553535', 'admin@mail.ru', '$2y$10$X.1c5MbKly/Q4PgnVnRG0enlq51Y95DGUAnSA/fpzJccsliRTh9Ke', 1, 2, '2022-06-08 03:05:28', '2022-06-08 03:05:28'),
(2, 'Пользователь', '88008888888', 'user@mail.ru', '$2y$10$1KNm2wi5KC5wTP/rdlaYaOxApzf1kix9tk4/ckBKveE6GjzG6rdYC', 1, 1, '2022-06-08 03:16:46', '2022-06-08 03:16:46');

-- --------------------------------------------------------

--
-- Структура таблицы `value_properties`
--

CREATE TABLE `value_properties` (
  `id` bigint UNSIGNED NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `property_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `value_properties`
--

INSERT INTO `value_properties` (`id`, `value`, `property_id`, `created_at`, `updated_at`) VALUES
(1, 'Золото', 1, NULL, NULL),
(2, 'Серебро', 1, NULL, NULL),
(3, 'Бронза', 1, NULL, NULL),
(4, 'Золотой', 2, NULL, NULL),
(5, 'Серебряный', 2, NULL, NULL),
(6, 'Бронзовый', 2, NULL, NULL),
(7, '20 см', 3, NULL, NULL),
(8, '30 см', 3, NULL, NULL),
(9, '40 см', 3, NULL, NULL),
(10, '200 гр', 4, NULL, NULL),
(11, '300 гр', 4, NULL, NULL),
(12, '400 гр', 4, NULL, NULL),
(13, 'Сталь', 1, NULL, NULL),
(14, 'Хром', 2, NULL, NULL),
(15, '50 см', 3, NULL, NULL),
(16, '500 гр', 4, NULL, NULL),
(17, 'Чёрный', 2, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `baskets`
--
ALTER TABLE `baskets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `baskets_user_id_foreign` (`user_id`),
  ADD KEY `baskets_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_address_id_foreign` (`address_id`),
  ADD KEY `orders_status_id_foreign` (`status_id`);

--
-- Индексы таблицы `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_products_order_id_foreign` (`order_id`),
  ADD KEY `order_products_product_id_foreign` (`product_id`);

--
-- Индексы таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Индексы таблицы `product_value_properties`
--
ALTER TABLE `product_value_properties`
  ADD KEY `product_value_properties_product_id_foreign` (`product_id`),
  ADD KEY `product_value_properties_value_property_id_foreign` (`value_property_id`);

--
-- Индексы таблицы `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Индексы таблицы `value_properties`
--
ALTER TABLE `value_properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `value_properties_property_id_foreign` (`property_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `baskets`
--
ALTER TABLE `baskets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `order_products`
--
ALTER TABLE `order_products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблицы `properties`
--
ALTER TABLE `properties`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `value_properties`
--
ALTER TABLE `value_properties`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `baskets`
--
ALTER TABLE `baskets`
  ADD CONSTRAINT `baskets_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `baskets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `product_value_properties`
--
ALTER TABLE `product_value_properties`
  ADD CONSTRAINT `product_value_properties_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_value_properties_value_property_id_foreign` FOREIGN KEY (`value_property_id`) REFERENCES `value_properties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `value_properties`
--
ALTER TABLE `value_properties`
  ADD CONSTRAINT `value_properties_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
